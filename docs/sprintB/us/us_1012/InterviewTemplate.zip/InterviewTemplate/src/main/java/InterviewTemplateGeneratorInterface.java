import java.io.IOException;

public interface InterviewTemplateGeneratorInterface {
    void interviewTemplateGenerator() throws IOException;
}
