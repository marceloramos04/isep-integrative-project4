import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class InterviewTemplateGeneratorImpl implements InterviewTemplateGeneratorInterface {

    public static void main(String[] args) {

    }

    @Override
    public void interviewTemplateGenerator() throws IOException {

        // Input Question File
        String inputFile = "questions.txt";

        // Output Template File
        String outputFile = "interview_template.txt";

        CharStream input = CharStreams.fromFileName(inputFile);

        InterviewTemplateLexer lexer = new InterviewTemplateLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        InterviewTemplateParser parser = new InterviewTemplateParser(tokens);

        // Parce input
        InterviewTemplateParser.TempleteContext context = parser.templete();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            for (InterviewTemplateParser.QuestionContext q : context.question()) {

                writer.write("Question: " + q.TEXT().getText() + "\n");
                writer.write("Answer: \n\n");
            }
        }
    }
}
