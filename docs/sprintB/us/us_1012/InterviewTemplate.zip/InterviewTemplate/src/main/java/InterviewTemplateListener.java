// Generated from InterviewTemplate.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link InterviewTemplateParser}.
 */
public interface InterviewTemplateListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link InterviewTemplateParser#templete}.
	 * @param ctx the parse tree
	 */
	void enterTemplete(InterviewTemplateParser.TempleteContext ctx);
	/**
	 * Exit a parse tree produced by {@link InterviewTemplateParser#templete}.
	 * @param ctx the parse tree
	 */
	void exitTemplete(InterviewTemplateParser.TempleteContext ctx);
	/**
	 * Enter a parse tree produced by {@link InterviewTemplateParser#question}.
	 * @param ctx the parse tree
	 */
	void enterQuestion(InterviewTemplateParser.QuestionContext ctx);
	/**
	 * Exit a parse tree produced by {@link InterviewTemplateParser#question}.
	 * @param ctx the parse tree
	 */
	void exitQuestion(InterviewTemplateParser.QuestionContext ctx);
}